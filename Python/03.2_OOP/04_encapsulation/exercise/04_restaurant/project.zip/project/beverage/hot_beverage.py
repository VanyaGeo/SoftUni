from project.beverage.beverage import Beverage


class HotBeverage(Beverage):
    pass
    # def __init__(self, name, price, milliliters):
    #     super().__init__(name, price, milliliters)